
LOGIAPP BACKEND – PRODUCTION READY

npm install
npm start

Includes:
- Auth JWT + bcrypt
- MongoDB
- Stripe subscription
- Roles & plans
