
import { useState } from 'react'
import axios from 'axios'

export default function App() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')

  const register = async () => {
    const res = await axios.post('http://localhost:5000/api/auth/register', { email, password })
    setMsg(res.data.message)
  }

  const login = async () => {
    const res = await axios.post('http://localhost:5000/api/auth/login', { email, password })
    setMsg(res.data.message)
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>Logiapp – Auth Demo</h1>
      <input placeholder="Email" onChange={e => setEmail(e.target.value)} /><br /><br />
      <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} /><br /><br />
      <button onClick={register}>Register</button>
      <button onClick={login} style={{ marginLeft: 10 }}>Login</button>
      <p>{msg}</p>
    </div>
  )
}
