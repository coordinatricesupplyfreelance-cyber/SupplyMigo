
const router = require('express').Router()
const Stripe = require('stripe')
const auth = require('../middleware/auth')
const User = require('../models/User')

const stripe = Stripe(process.env.STRIPE_SECRET_KEY)

router.post('/checkout', auth, async(req,res)=>{
 const session = await stripe.checkout.sessions.create({
  mode:'subscription',
  line_items:[{price:process.env.STRIPE_PRICE_ID,quantity:1}],
  success_url:process.env.SUCCESS_URL,
  cancel_url:process.env.CANCEL_URL
 })
 res.json({url:session.url})
})

module.exports = router
